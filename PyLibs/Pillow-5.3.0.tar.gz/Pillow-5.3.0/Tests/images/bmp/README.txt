These images are from the bmpsuite:
https://github.com/jsummers/bmpsuite and are in the public domain
according to the readme in the project.
